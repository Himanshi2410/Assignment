public class Book
{
  private int bookId;
  private String title;
   private String author;
  private float price

public void setBookId(int bookId)
{
this.bookId=bookId;


public int getBookId(){
return bookId;
}
public void setTitle(int title)
{
this.title=title;

public int getTitle()
{
return title;
}
public void setAuthor(String Author)
{
this.author=author;
public string getAuthor()
{
return author;
}
}
}

